package com.example.heladeria.repository;

import com.example.heladeria.utils.HibernateUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;

public abstract class BaseRepository {

    protected EntityManager getEntityManager() {

        return HibernateUtils
                .getEntityManagerFactory()
                .createEntityManager();
    }

    protected void rollback(EntityTransaction transaction) {

        if (transaction != null && transaction.isActive()) {

            transaction.rollback();
        }
    }
}


/*
Creé una clase BaseRepository para reutilizar funciones comunes entre los repositories y evitar repetir código.
 */