package com.example.heladeria.repository;

import com.example.heladeria.model.UsuarioEntity;
import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityTransaction;
import jakarta.persistence.NoResultException;

import java.util.List;
import java.util.Optional;

public class UsuarioRepository extends BaseRepository {

    public Optional<UsuarioEntity> login(String nombreUsuario, String password) {

        EntityManager entityManager = getEntityManager();

        try {

            UsuarioEntity usuario = entityManager
                    .createNamedQuery(
                            "UsuarioEntity.login",
                            UsuarioEntity.class
                    )
                    .setParameter("nombre", nombreUsuario)
                    .setParameter("password", password)
                    .getSingleResult();

            return Optional.of(usuario);

        } catch (NoResultException e) {

            return Optional.empty();

        } finally {

            entityManager.close();
        }
    }

    public boolean addUser(UsuarioEntity usuario) {

        EntityManager entityManager = getEntityManager();

        EntityTransaction transaction =
                entityManager.getTransaction();

        try {

            transaction.begin();

            entityManager.persist(usuario);

            transaction.commit();

            return true;

        } catch (Exception e) {

            rollback(transaction);

            return false;

        } finally {

            entityManager.close();
        }
    }

    public List<UsuarioEntity> getAllUsers() {

        EntityManager entityManager = getEntityManager();

        try {

            return entityManager
                    .createQuery(
                            "FROM UsuarioEntity",
                            UsuarioEntity.class
                    )
                    .getResultList();

        } finally {

            entityManager.close();
        }
    }

    public Optional<UsuarioEntity> getUserByID(int id) {

        EntityManager entityManager = getEntityManager();

        try {

            UsuarioEntity usuario =
                    entityManager.find(
                            UsuarioEntity.class,
                            id
                    );

            return Optional.ofNullable(usuario);

        } finally {

            entityManager.close();
        }
    }

    public boolean updateUser(UsuarioEntity usuario) {

        EntityManager entityManager = getEntityManager();

        EntityTransaction transaction =
                entityManager.getTransaction();

        try {

            transaction.begin();

            entityManager.merge(usuario);

            transaction.commit();

            return true;

        } catch (Exception e) {

            rollback(transaction);

            return false;

        } finally {

            entityManager.close();
        }
    }

    public boolean removeUser(int id) {

        EntityManager entityManager = getEntityManager();

        EntityTransaction transaction =
                entityManager.getTransaction();

        try {

            transaction.begin();

            UsuarioEntity usuario =
                    entityManager.find(
                            UsuarioEntity.class,
                            id
                    );

            if (usuario != null) {

                entityManager.remove(usuario);
            }

            transaction.commit();

            return true;

        } catch (Exception e) {

            rollback(transaction);

            return false;

        } finally {

            entityManager.close();
        }
    }

    public Optional<UsuarioEntity> getUserByName(String nombre) {

        EntityManager entityManager = getEntityManager();

        try {

            UsuarioEntity usuario = entityManager
                    .createQuery(
                            "SELECT u FROM UsuarioEntity u WHERE u.nombre = :nombre",
                            UsuarioEntity.class
                    )
                    .setParameter("nombre", nombre)
                    .getSingleResult();

            return Optional.of(usuario);

        } catch (NoResultException e) {

            return Optional.empty();

        } finally {

            entityManager.close();
        }
    }

    public boolean existsUser(String nombre) {

        EntityManager entityManager = getEntityManager();

        try {

            Long cantidad = entityManager
                    .createQuery(
                            "SELECT COUNT(u) FROM UsuarioEntity u WHERE u.nombre = :nombre",
                            Long.class
                    )
                    .setParameter("nombre", nombre)
                    .getSingleResult();

            return cantidad > 0;

        } finally {

            entityManager.close();
        }
    }
}