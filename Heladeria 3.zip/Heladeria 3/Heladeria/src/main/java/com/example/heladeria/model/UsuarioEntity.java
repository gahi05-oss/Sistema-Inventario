package com.example.heladeria.model;

import jakarta.persistence.*;
import org.hibernate.annotations.GenericGenerator;

import java.time.LocalDate;

@Entity
@Table( name = "usuarios" )
@NamedQuery(
        name = "UsuarioEntity.login",
        query = "SELECT u FROM UsuarioEntity u WHERE u.nombre_usuario = :nombre AND u.password = :password AND u.activo = 1"
)

public class UsuarioEntity {
    private int id_usuario;
    private String nombre_usuario;
    private String password;
    private RolEntity rol;
    private int activo;

    public UsuarioEntity(){

    }

    public UsuarioEntity(String nombre_usuario, String password, RolEntity rol, int activo) {
        this.nombre_usuario = nombre_usuario;
        this.password = password;
        this.rol = rol;
        this.activo = activo;
    }

    @Id
    @GeneratedValue(generator="increment")
    @GenericGenerator(name="increment", strategy = "increment")
    @Column(name = "id_usuario")
    public int getId() {
        return id_usuario;
    }

    private void setId(int id) {
        this.id_usuario = id;
    }

    @Column(name = "nombre_usuario", nullable = false, unique = true)
    public String getNombre_usuario() {
        return nombre_usuario;
    }

    public void setNombre_usuario(String nombre_usuario) {
        this.nombre_usuario = nombre_usuario;
    }

    public String getPassword() {
        return password;
    }

    @Column(name = "password", nullable = false)
    public void setPassword(String password) {
        this.password = password;
    }

    @Column(name = "activo", nullable = false)
    public int getActivo() {
        return activo;
    }

    public void setActivo(int activo) {
        this.activo = activo;
    }

    // RELACIÓN N:1 CON ROL
    @ManyToOne(cascade = {CascadeType.PERSIST, CascadeType.MERGE})
    @JoinColumn(name = "id_rol", referencedColumnName = "id_rol")
    public RolEntity getRol() {
        return rol;
    }

    public void setRol(RolEntity rol) {
        this.rol = rol;
    }

}
