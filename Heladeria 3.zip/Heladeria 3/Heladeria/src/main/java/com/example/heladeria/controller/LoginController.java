package com.example.heladeria.controller;

import com.example.heladeria.HelloApplication;
import com.example.heladeria.model.UsuarioEntity;
import com.example.heladeria.services.UsuarioService;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private Button btnIniciarSesion;

    @FXML
    private Label lblError;

    @FXML
    private ImageView logoImageView;

    @FXML
    private PasswordField txtContrasena;

    @FXML
    private TextField txtUsuario;

    private final UsuarioService usuarioService = new UsuarioService();

    @FXML
    void handleIniciarSesion() throws IOException {
        String usuario = txtUsuario.getText();
        String password = txtContrasena.getText();

        UsuarioEntity user = usuarioService.login(usuario, password);

        if (user != null) {

            String rol = user.getRol().getNombre();

            System.out.println("Login exitoso");
            System.out.println("Rol: " + rol);

            FXMLLoader fxmlLoader;

            if (rol.equalsIgnoreCase("administrador")) {
                System.out.println("Abrir vista administrador");
                fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Administrador/AdminProductos.fxml"));
            } else {
                fxmlLoader = new FXMLLoader(HelloApplication.class.getResource("Encargado/EncargadoActualizar.fxml"));
            }

            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) txtUsuario.getScene().getWindow();

            stage.setScene(scene);
            stage.setTitle("Heladería");
            stage.show();

        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error en inicio de sesión");
            alert.setContentText("Usuario o contraseña incorrectos");
            alert.showAndWait();
        }
    }

}
