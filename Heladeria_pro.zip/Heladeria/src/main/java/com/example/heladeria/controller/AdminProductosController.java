/*package com.example.heladeria.controller;

import com.example.heladeria.model.ProductoEntity;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.collections.transformation.FilteredList;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.math.BigDecimal;
import java.net.URL;

import com.example.heladeria.model.CategoriaEntity;
import com.example.heladeria.model.ProductoEntity;
import com.example.heladeria.repository.CategoriaRepositorio;
import com.example.heladeria.services.ProductoServicio;


public class AdminProductosController {

    @FXML private TextField txtIdProducto, txtNombre, txtStock, txtPrecio, txtFiltro;
    @FXML private ComboBox<String> cmbCategoria;

    @FXML private TableView<ProductoEntity> tablaProductos;
    @FXML private TableColumn<ProductoEntity, Integer> colIdProd;
    @FXML private TableColumn<ProductoEntity, String> colNombre;
    @FXML private TableColumn<ProductoEntity, Integer> colStock;
    @FXML private TableColumn<ProductoEntity, BigDecimal> colPrecio;

    // Objeto de Servicio y repositorio
   /* private ProductoServicio productoServicio = new ProductoServicio();
    private CategoriaRepositorio categoriaRepo = new CategoriaRepositorio();
    private ObservableList<ProductoEntity> listaProductos = FXCollections.observableArrayList();
    */
    /*private final ObservableList<ProductoEntity> listaLocal = FXCollections.observableArrayList();
    private FilteredList<ProductoEntity> listaFiltrada;

    @FXML
    public void initialize() {
        if (colIdProd == null) {
            System.err.println("ERROR: colIdProd es null. Revisa el fx:id en el FXML.");
            return;
        }

        colIdProd.setCellValueFactory(new PropertyValueFactory<>("id"));
        colNombre.setCellValueFactory(new PropertyValueFactory<>("nombre"));
        colPrecio.setCellValueFactory(new PropertyValueFactory<>("precio"));
        colStock.setCellValueFactory(new PropertyValueFactory<>("stock"));

        if (cmbCategoria != null) {
            cmbCategoria.getItems().addAll("Helados", "Paletas", "Bebidas", "Postres");
        }

        listaFiltrada = new FilteredList<>(listaLocal, p -> true);
        tablaProductos.setItems(listaFiltrada);

        tablaProductos.getSelectionModel().selectedItemProperty().addListener((obs, oldSelection, newSelection) -> {
            if (newSelection != null) {
                txtIdProducto.setText(String.valueOf(newSelection.getId()));
                txtNombre.setText(newSelection.getNombre());
                txtPrecio.setText(newSelection.getPrecio().toString());
                txtStock.setText(String.valueOf(newSelection.getStock()));
            }
        });
    }

    @FXML
    void handleAgregar(ActionEvent event) {
        try {
            int id = txtIdProducto.getText().isEmpty() ?
                    listaLocal.size() + 1 :
                    Integer.parseInt(txtIdProducto.getText());

            ProductoEntity nuevo = new ProductoEntity(
                    id,
                    txtNombre.getText(),
                    new BigDecimal(txtPrecio.getText()),
                    Integer.parseInt(txtStock.getText())
            );

            listaLocal.add(nuevo);
            handleCancelar(null);
        } catch (Exception e) {
            System.out.println("Error al agregar: " + e.getMessage());
        }
    }

    @FXML
    void handleBuscar(ActionEvent event) {
        String filtro = txtFiltro.getText().toLowerCase();
        listaFiltrada.setPredicate(p -> {
            if (filtro == null || filtro.isEmpty()) return true;
            return p.getNombre().toLowerCase().contains(filtro);
        });
    }

    @FXML
    void handleEditar(ActionEvent event) {
        ProductoEntity seleccionado = tablaProductos.getSelectionModel().getSelectedItem();
        if (seleccionado != null) {
            try {
                seleccionado.setNombre(txtNombre.getText());
                seleccionado.setPrecio(new BigDecimal(txtPrecio.getText()));
                seleccionado.setStock(Integer.parseInt(txtStock.getText()));
                tablaProductos.refresh();
                handleCancelar(null);
            } catch (Exception e) {
                System.out.println("Error al editar: " + e.getMessage());
            }
        }
    }

    @FXML
    void handleEliminar(ActionEvent event) {
        ProductoEntity seleccionado = tablaProductos.getSelectionModel().getSelectedItem();
        if (seleccionado != null) {
            listaLocal.remove(seleccionado);
            handleCancelar(null);
        }
    }

    @FXML
    public void handleCancelar(ActionEvent actionEvent) {
        txtIdProducto.clear();
        txtNombre.clear();
        txtPrecio.clear();
        txtStock.clear();
        if (cmbCategoria != null) cmbCategoria.getSelectionModel().clearSelection();
        tablaProductos.getSelectionModel().clearSelection();
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML, String titulo) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) return;
            Parent root = FXMLLoader.load(fxmlUrl);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(titulo);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML void handleProductos(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminProductos.fxml", "Productos"); }
    @FXML void handleMovimiento(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminMovimiento.fxml", "Movimientos"); }
    @FXML void handleNuevoEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminNuevoEmpleado.fxml", "Nuevo Empleado"); }
    @FXML void handleEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminEmpleado.fxml", "Empleados"); }
    @FXML void handleListado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminListado.fxml", "Listados"); }
    @FXML void handleCerrarSesion(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Login.fxml", "Login"); }
}*/

package com.example.heladeria.controller;

import com.example.heladeria.model.CategoriaEntity;
import com.example.heladeria.model.ProductoEntity;
import com.example.heladeria.repository.CategoriaRepositorio;
import com.example.heladeria.services.ProductoServicio;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;
import java.util.List;

public class AdminProductosController {

    @FXML private TextField txtIdProducto, txtNombre, txtStock, txtPrecio, txtFiltro;
    @FXML private ComboBox<String> cmbCategoria;
    @FXML private TableView<ProductoEntity> tablaProductos;

    private final ProductoServicio productoServicio = new ProductoServicio();
    private final CategoriaRepositorio categoriaRepo = new CategoriaRepositorio();

    @FXML
    public void initialize() {
        // Validación de seguridad para evitar el NullPointerException de la consola
        if (cmbCategoria == null) {
            System.err.println("Error: cmbCategoria es null. Verifica el fx:id en el FXML.");
            return;
        }

        try {
            List<CategoriaEntity> lista = categoriaRepo.obtenerTodas();
            cmbCategoria.getItems().clear();
            if (lista != null && !lista.isEmpty()) {
                for (CategoriaEntity cat : lista) {
                    cmbCategoria.getItems().add(cat.getNombre());
                }
            } else {
                // Carga manual si la base de datos está vacía
                cmbCategoria.setItems(FXCollections.observableArrayList("Helados", "Paletas", "Bebidas"));
            }
        } catch (Exception e) {
            System.err.println("Error al cargar categorías de la BD: " + e.getMessage());
            cmbCategoria.setItems(FXCollections.observableArrayList("Helados", "Paletas", "Bebidas"));
        }

        System.out.println("Modo Formulario: Visualización de tabla deshabilitada temporalmente.");
    }

    @FXML
    void handleAgregar(ActionEvent event) {
        if (cmbCategoria.getValue() == null) {
            mostrarAlerta("Validación", "Por favor selecciona una categoría.", Alert.AlertType.WARNING);
            return;
        }
        try {
            productoServicio.registrarProducto(
                    txtNombre.getText(),
                    cmbCategoria.getValue(),
                    txtPrecio.getText(),
                    txtStock.getText()
            );
            mostrarAlerta("Éxito", "Producto guardado correctamente.", Alert.AlertType.INFORMATION);
            handleCancelar(null);
        } catch (Exception e) {
            mostrarAlerta("Error al guardar", e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    void handleEditar(ActionEvent event) {
        try {
            if (txtIdProducto.getText().isEmpty()) throw new Exception("ID requerido.");
            int id = Integer.parseInt(txtIdProducto.getText());
            productoServicio.actualizarProducto(
                    id,
                    txtNombre.getText(),
                    cmbCategoria.getValue(),
                    txtPrecio.getText(),
                    txtStock.getText()
            );
            mostrarAlerta("Éxito", "Producto actualizado correctamente.", Alert.AlertType.INFORMATION);
            handleCancelar(null);
        } catch (Exception e) {
            mostrarAlerta("Error", "Error al actualizar: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    @FXML
    void handleEliminar(ActionEvent event) {
        try {
            if (txtIdProducto.getText().isEmpty()) throw new Exception("ID requerido.");
            int id = Integer.parseInt(txtIdProducto.getText());
            productoServicio.eliminarProducto(id);
            mostrarAlerta("Éxito", "Producto marcado como inactivo.", Alert.AlertType.INFORMATION);
            handleCancelar(null);
        } catch (Exception e) {
            mostrarAlerta("Error", "Ingresa un ID válido para eliminar.", Alert.AlertType.ERROR);
        }
    }

    @FXML
    void handleBuscar(ActionEvent event) {
        mostrarAlerta("Info", "La búsqueda se habilitará al implementar DTOs.", Alert.AlertType.INFORMATION);
    }

    @FXML
    public void handleCancelar(ActionEvent actionEvent) {
        txtIdProducto.clear();
        txtNombre.clear();
        txtPrecio.clear();
        txtStock.clear();
        if (txtFiltro != null) txtFiltro.clear();
        if (cmbCategoria != null) cmbCategoria.getSelectionModel().clearSelection();
    }

    private void mostrarAlerta(String titulo, String mensaje, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML, String titulo) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) {
                System.err.println("No se encontró el archivo FXML: " + rutaFXML);
                return;
            }
            Parent root = FXMLLoader.load(fxmlUrl);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(titulo);
            stage.show();
        } catch (IOException e) { e.printStackTrace(); }
    }

    @FXML void handleProductos(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminProductos.fxml", "Productos"); }
    @FXML void handleMovimiento(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminMovimiento.fxml", "Movimientos"); }
    @FXML void handleNuevoEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminNuevoEmpleado.fxml", "Nuevo Empleado"); }
    @FXML void handleEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminEmpleado.fxml", "Empleados"); }
    @FXML void handleListado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminListado.fxml", "Listados"); }
    @FXML void handleCerrarSesion(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Login.fxml", "Login"); }
}