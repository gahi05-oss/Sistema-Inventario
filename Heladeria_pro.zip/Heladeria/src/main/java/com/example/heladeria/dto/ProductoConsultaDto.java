package com.example.heladeria.dto;

import java.math.BigDecimal;

public record ProductoConsultaDto (
        int IDProducto,
        String nombre,
        BigDecimal precio,
        int stock
){}

