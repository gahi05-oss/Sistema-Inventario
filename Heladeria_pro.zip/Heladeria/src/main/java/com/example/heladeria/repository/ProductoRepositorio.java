package com.example.heladeria.repository;

import com.example.heladeria.model.ProductoEntity;
import com.example.heladeria.utils.HibernateUtils;
import jakarta.persistence.EntityManager;
import java.util.List;

public class ProductoRepositorio {
    // Metodo para resigistra y actualizar
    public void guardarOActualizar(ProductoEntity producto) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            em.getTransaction().begin();
            if (producto.getId() == 0) {
                em.persist(producto); // Inserta un registro nuevo
            } else {
                em.merge(producto);   // Actualiza un registro existente
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw new RuntimeException("Error en la base de datos al guardar el producto.", e);
        } finally {
            em.close();
        }
    }

    // Metodo para buscar un producto por su ID
    public ProductoEntity buscarPorId(int id) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.find(ProductoEntity.class, id);
        } finally {
            em.close();
        }
    }

    // Metod para buscar todos los productos activos
    public List<ProductoEntity> obtenerTodosActivos() {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("SELECT p FROM ProductoEntity p WHERE p.activo = 1", ProductoEntity.class).getResultList();
        } finally {
            em.close();
        }
    }

    // Metodo para la busqueda por filtros de productos
    public List<ProductoEntity> buscarPorFiltro(String texto) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            String jpql = "SELECT p FROM ProductoEntity p WHERE p.activo = 1 AND (LOWER(p.nombre) LIKE LOWER(:texto) OR LOWER(p.categoria.nombre) LIKE LOWER(:texto))";
            return em.createQuery(jpql, ProductoEntity.class)
                    .setParameter("texto", "%" + texto + "%")
                    .getResultList();
        } finally {
            em.close();
        }
    }
}
