package com.example.heladeria.dto;

public record UsuarioRegistroDto (
        String nombreUsuario,
        String password,
        int idRol
){}

