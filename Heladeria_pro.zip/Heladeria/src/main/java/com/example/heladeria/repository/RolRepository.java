package com.example.heladeria.repository;

import com.example.heladeria.model.RolEntity;
import com.example.heladeria.utils.HibernateUtils;
import jakarta.persistence.EntityManager;
import java.util.List;


public class RolRepository {

    // Metodo para buscar por nombre, importante para el Datainitializer
    public RolEntity buscarPorNombre(String nombre) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("SELECT r FROM RolEntity r WHERE r.nombre = :nom", RolEntity.class)
                    .setParameter("nom", nombre)
                    .getSingleResult();
        } catch (Exception e) {
            // Retorna null si el rol no existe (evita que la aplicación se detenga)
            return null;
        } finally {
            em.close();
        }
    }

    // Metodo para agregar un nuevo rol y usado por el Datainializer
    public void addRol(RolEntity rol) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            em.getTransaction().begin();
            em.persist(rol);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            throw new RuntimeException("Error al insertar el rol en la base de datos.", e);
        } finally {
            em.close();
        }
    }

    // Metodo para contar los roles
    public long countRoles() {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("SELECT COUNT(r) FROM RolEntity r", Long.class)
                    .getSingleResult();
        } finally {
            em.close();
        }
    }

    // Metodo para obtener la lista de roles
    public List<RolEntity> obtenerTodos() {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("SELECT r FROM RolEntity r", RolEntity.class).getResultList();
        } finally {
            em.close();
        }
    }
}