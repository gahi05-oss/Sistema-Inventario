package com.example.heladeria.repository;

import com.example.heladeria.dto.MovimientoVistaDto;
import com.example.heladeria.model.MovimientoInventarioEntity;
import com.example.heladeria.utils.HibernateUtils;
import jakarta.persistence.EntityManager;
import java.util.List;

public class MovimientoRepositorio {

    public void guardarOActualizar(MovimientoInventarioEntity movimiento) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            em.getTransaction().begin();
            if (movimiento.getId() == 0) {
                em.persist(movimiento);
            } else {
                em.merge(movimiento);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            throw new RuntimeException("Error en BD al guardar movimiento.", e);
        } finally {
            em.close();
        }
    }

    public MovimientoInventarioEntity buscarPorId(int id) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.find(MovimientoInventarioEntity.class, id);
        } finally {
            em.close();
        }
    }

    public void eliminar(MovimientoInventarioEntity movimiento) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            em.getTransaction().begin();
            // Verificamos si el objeto está "conectado" a esta sesión antes de borrarlo
            MovimientoInventarioEntity m = em.contains(movimiento) ? movimiento : em.merge(movimiento);
            em.remove(m);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) em.getTransaction().rollback();
            throw new RuntimeException("Error al eliminar el movimiento.", e);
        } finally {
            em.close();
        }
    }

    public List<MovimientoInventarioEntity> obtenerTodos() {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("SELECT m FROM MovimientoInventarioEntity m ORDER BY m.fecha DESC", MovimientoInventarioEntity.class).getResultList();
        } finally {
            em.close();
        }
    }

    public List<MovimientoVistaDto> obtenerTodosView() {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();

        try {
            String jpql = "SELECT new com.example.heladeria.dto.MovimientoVistaDto(" +
                    "m.fecha, " +
                    "p.id, " +
                    "p.nombre, " +
                    "m.tipoMovimiento, " +
                    "m.cantidad, " +
                    "e.id) " +
                    "FROM MovimientoInventarioEntity m " +
                    "JOIN m.producto p " +
                    "JOIN m.empleado e";

            return em.createQuery(jpql, MovimientoVistaDto.class).getResultList();
        } finally {
            em.close();
        }
    }
}
