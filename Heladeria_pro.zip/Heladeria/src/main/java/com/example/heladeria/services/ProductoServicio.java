/*package com.example.heladeria.services;

import com.example.heladeria.model.CategoriaEntity;
import com.example.heladeria.model.ProductoEntity;
import com.example.heladeria.repository.CategoriaRepositorio;
import com.example.heladeria.repository.ProductoRepositorio;
import java.math.BigDecimal;
import java.util.List;

public class ProductoServicio {
    private ProductoRepositorio productoRepositorio = new ProductoRepositorio();
    private CategoriaRepositorio categoriaRepositorio = new CategoriaRepositorio();

    // 1. REGISTRAR (Agregar producto nuevo)
    public void registrarProducto(String nombre, String nombreCategoria, String precioTexto, String stockTexto) {
        validarCamposVacios(nombre, nombreCategoria, precioTexto, stockTexto);

        try {
            BigDecimal precio = new BigDecimal(precioTexto);
            int stock = Integer.parseInt(stockTexto);
            validarNumeros(precio, stock);

            CategoriaEntity categoria = buscarCategoriaValidada(nombreCategoria);

            // Se envía el ID en 0 para que MySQL lo genere automáticamente
            ProductoEntity nuevoProducto = new ProductoEntity(0, nombre, precio, stock);
            nuevoProducto.setCategoria(categoria);

            productoRepositorio.guardarOActualizar(nuevoProducto);

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("El precio y el stock deben ser números válidos.");
        }
    }

    // 2. ACTUALIZAR (Editar producto existente)
    public void actualizarProducto(int idProducto, String nombre, String nombreCategoria, String precioTexto, String stockTexto) {
        validarCamposVacios(nombre, nombreCategoria, precioTexto, stockTexto);

        ProductoEntity productoExistente = productoRepositorio.buscarPorId(idProducto);
        if (productoExistente == null) {
            throw new IllegalArgumentException("El producto que intentas editar no existe.");
        }

        try {
            BigDecimal precio = new BigDecimal(precioTexto);
            int stock = Integer.parseInt(stockTexto);
            validarNumeros(precio, stock);

            CategoriaEntity categoria = buscarCategoriaValidada(nombreCategoria);

            // Modificamos el objeto encontrado con los datos nuevos
            productoExistente.setNombre(nombre);
            productoExistente.setCategoria(categoria);
            productoExistente.setPrecio(precio);
            productoExistente.setStock(stock);

            productoRepositorio.guardarOActualizar(productoExistente);

        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("El precio y el stock deben ser números válidos.");
        }
    }

    // 3. ELIMINAR (Baja Lógica)
    public void eliminarProducto(int idProducto) {
        ProductoEntity producto = productoRepositorio.buscarPorId(idProducto);
        if (producto == null) {
            throw new IllegalArgumentException("El producto que intentas eliminar no existe.");
        }

        // Cambiamos el estado a 0 (inactivo) para no romper el historial de la BD
        producto.setActivo(0);
        productoRepositorio.guardarOActualizar(producto);
    }

    // 4. BUSCAR TODOS
    public List<ProductoEntity> obtenerTodosLosProductos() {
        return productoRepositorio.obtenerTodosActivos();
    }

    // 5. BUSCAR POR FILTRO
    public List<ProductoEntity> buscarProductosPorFiltro(String textoBuscado) {
        if (textoBuscado == null || textoBuscado.trim().isEmpty()) {
            return obtenerTodosLosProductos();
        }
        return productoRepositorio.buscarPorFiltro(textoBuscado);
    }

    // --- MÉTODOS AUXILIARES ---
    private void validarCamposVacios(String nombre, String categoria, String precio, String stock) {
        if (nombre == null || nombre.trim().isEmpty() || categoria == null || categoria.trim().isEmpty() ||
                precio == null || precio.trim().isEmpty() || stock == null || stock.trim().isEmpty()) {
            throw new IllegalArgumentException("Todos los campos son obligatorios.");
        }
    }

    private void validarNumeros(BigDecimal precio, int stock) {
        if (precio.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor a cero.");
        }
        if (stock < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo.");
        }
    }

    private CategoriaEntity buscarCategoriaValidada(String nombreCategoria) {
        CategoriaEntity categoria = categoriaRepositorio.buscarPorNombre(nombreCategoria);
        if (categoria == null) {
            throw new IllegalArgumentException("La categoría '" + nombreCategoria + "' no existe en la base de datos.");
        }
        return categoria;
    }
}*/

package com.example.heladeria.services;

import com.example.heladeria.model.CategoriaEntity;
import com.example.heladeria.model.ProductoEntity;
import com.example.heladeria.repository.CategoriaRepositorio;
import com.example.heladeria.repository.ProductoRepositorio;
import java.math.BigDecimal;
import java.util.List;

public class ProductoServicio {
    private ProductoRepositorio productoRepositorio = new ProductoRepositorio();
    private CategoriaRepositorio categoriaRepositorio = new CategoriaRepositorio();

    public void registrarProducto(String nombre, String nombreCategoria, String precioTexto, String stockTexto) {
        validarEntrada(nombre, nombreCategoria, precioTexto, stockTexto);
        try {
            BigDecimal precio = new BigDecimal(precioTexto);
            int stock = Integer.parseInt(stockTexto);
            validarValoresNumericos(precio, stock);

            CategoriaEntity categoria = buscarCategoriaValidada(nombreCategoria);

            ProductoEntity nuevoProducto = new ProductoEntity(0, nombre, precio, stock);
            nuevoProducto.setCategoria(categoria);
            nuevoProducto.setActivo(1);

            productoRepositorio.guardarOActualizar(nuevoProducto);
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("El precio debe ser decimal y el stock un número entero.");
        }
    }

    public void actualizarProducto(int id, String nombre, String nombreCat, String precio, String stock) {
        ProductoEntity p = productoRepositorio.buscarPorId(id);
        if (p != null) {
            p.setNombre(nombre);
            p.setPrecio(new BigDecimal(precio));
            p.setStock(Integer.parseInt(stock));
            CategoriaEntity cat = categoriaRepositorio.buscarPorNombre(nombreCat);
            if (cat != null) p.setCategoria(cat);
            productoRepositorio.guardarOActualizar(p);
        }
    }

    public void eliminarProducto(int id) {
        ProductoEntity p = productoRepositorio.buscarPorId(id);
        if (p != null) {
            p.setActivo(0); // Baja lógica
            productoRepositorio.guardarOActualizar(p);
        }
    }

    public List<ProductoEntity> buscarProductosPorFiltro(String texto) {
        if (texto == null || texto.isBlank()) return obtenerTodosLosProductos();
        return productoRepositorio.buscarPorFiltro(texto);
    }

    public List<ProductoEntity> obtenerTodosLosProductos() {
        return productoRepositorio.obtenerTodosActivos();
    }

    // --- MÉTODOS AUXILIARES ---
    private void validarEntrada(String nombre, String categoria, String precio, String stock) {
        if (nombre == null || nombre.isBlank() || categoria == null || categoria.isBlank() ||
                precio == null || precio.isBlank() || stock == null || stock.isBlank()) {
            throw new IllegalArgumentException("Todos los campos son obligatorios.");
        }
    }

    private void validarValoresNumericos(BigDecimal precio, int stock) {
        if (precio.compareTo(BigDecimal.ZERO) <= 0) {
            throw new IllegalArgumentException("El precio debe ser mayor a cero.");
        }
        if (stock < 0) {
            throw new IllegalArgumentException("El stock no puede ser negativo.");
        }
    }

    private CategoriaEntity buscarCategoriaValidada(String nombreCategoria) {
        CategoriaEntity categoria = categoriaRepositorio.buscarPorNombre(nombreCategoria);
        if (categoria == null) {
            throw new IllegalArgumentException("La categoría '" + nombreCategoria + "' no existe en la BD.");
        }
        return categoria;
    }
}