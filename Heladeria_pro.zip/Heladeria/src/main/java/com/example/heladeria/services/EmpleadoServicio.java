/*package com.example.heladeria.services;

import com.example.heladeria.model.EmpleadoEntity;
import com.example.heladeria.repository.EmpleadoRepositorio;
import java.util.List;

public class EmpleadoServicio {
    private EmpleadoRepositorio empleadoRepositorio = new EmpleadoRepositorio();

    // 1. REGISTRAR (Agregar empleado nuevo)
    public void registrarEmpleado(String nombre, String apellidoPaterno, String apellidoMaterno, String telefono) {
        validarCamposObligatorios(nombre, apellidoPaterno);

        // El ID va en 0 para que MySQL lo asigne automáticamente con el AutoIncrement
        EmpleadoEntity nuevoEmpleado = new EmpleadoEntity(0, nombre, apellidoPaterno, apellidoMaterno, telefono);

        // Nota: Aquí el 'UsuarioEntity' queda nulo por defecto.
        // Si después quieres que el empleado tenga acceso al sistema, se le debe asignar un Usuario.

        empleadoRepositorio.guardarOActualizar(nuevoEmpleado);
    }

    // 2. ACTUALIZAR (Editar un empleado existente)
    public void actualizarEmpleado(int idEmpleado, String nombre, String apellidoPaterno, String apellidoMaterno, String telefono) {
        validarCamposObligatorios(nombre, apellidoPaterno);

        EmpleadoEntity empleadoExistente = empleadoRepositorio.buscarPorId(idEmpleado);
        if (empleadoExistente == null) {
            throw new IllegalArgumentException("El empleado que intentas editar no existe en el sistema.");
        }

        // Reemplazamos la información vieja por la nueva
        empleadoExistente.setNombre(nombre);
        empleadoExistente.setApellido_paterno(apellidoPaterno);
        empleadoExistente.setApellido_materno(apellidoMaterno);
        empleadoExistente.setTelefono(telefono);

        empleadoRepositorio.guardarOActualizar(empleadoExistente);
    }

    // 3. ELIMINAR (Borrado físico)
    public void eliminarEmpleado(int idEmpleado) {
        EmpleadoEntity empleadoExistente = empleadoRepositorio.buscarPorId(idEmpleado);
        if (empleadoExistente == null) {
            throw new IllegalArgumentException("No se encontró el empleado a eliminar.");
        }

        // Si el empleado ya tiene movimientos de inventario asociados, la BD podría lanzar un error de integridad.
        empleadoRepositorio.eliminar(empleadoExistente);
    }

    // 4. BUSCAR TODOS
    public List<EmpleadoEntity> obtenerTodosLosEmpleados() {
        return empleadoRepositorio.obtenerTodos();
    }

    // 5. BUSCAR POR FILTRO (Nombre o apellidos)
    public List<EmpleadoEntity> buscarEmpleadosPorFiltro(String textoBuscado) {
        if (textoBuscado == null || textoBuscado.trim().isEmpty()) {
            return obtenerTodosLosEmpleados();
        }
        return empleadoRepositorio.buscarPorFiltro(textoBuscado);
    }

    // --- MERODO AUXILIAR DE VALIDACION
    private void validarCamposObligatorios(String nombre, String apellidoPaterno) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre del empleado es obligatorio.");
        }
        if (apellidoPaterno == null || apellidoPaterno.trim().isEmpty()) {
            throw new IllegalArgumentException("El apellido paterno es obligatorio.");
        }
    }
}*/

package com.example.heladeria.services;

import com.example.heladeria.model.*;
import com.example.heladeria.repository.*;
import java.util.List;

public class EmpleadoServicio {
    private EmpleadoRepositorio empleadoRepositorio = new EmpleadoRepositorio();
    private RolRepository rolRepository = new RolRepository();


    public void registrarEmpleadoConUsuario(String nombre, String apellidoPaterno, String apellidoMaterno,
                                            String telefono, String login, String password, String nombreRol) {

        // Validaciones de negocio
        validarCamposObligatorios(nombre, apellidoPaterno);
        if (login == null || login.isBlank()) throw new IllegalArgumentException("El nombre de usuario es obligatorio.");
        if (password == null || password.isBlank()) throw new IllegalArgumentException("La contraseña es obligatoria.");

        // Buscar el Rol (Debe coincidir con 'Administrador' o 'Empleado' en la BD)
        RolEntity rol = rolRepository.buscarPorNombre(nombreRol);
        if (rol == null) {
            throw new IllegalArgumentException("El rol '" + nombreRol + "' no existe en la base de datos.");
        }

        try {
            // Crear la entidad Usuario (sin persistir aún)
            UsuarioEntity nuevoUsuario = new UsuarioEntity();
            nuevoUsuario.setNombre_usuario(login);
            nuevoUsuario.setPassword(password);
            nuevoUsuario.setRol(rol);
            nuevoUsuario.setActivo(1);

            // Crear la entidad Empleado y vincular el usuario
            // El ID 0 indica a MySQL que use AUTO_INCREMENT
            EmpleadoEntity nuevoEmpleado = new EmpleadoEntity(0, nombre, apellidoPaterno, apellidoMaterno, telefono);
            nuevoEmpleado.setUsuario(nuevoUsuario);

            // Guardar el empleado (y por cascada, el usuario)
            empleadoRepositorio.guardarOActualizar(nuevoEmpleado);

        } catch (Exception e) {
            // Captura el error de 'Duplicate entry' que vimos en tu consola
            if (e.getMessage() != null && e.getMessage().contains("Duplicate entry")) {
                throw new RuntimeException("El nombre de usuario '" + login + "' ya está en uso.");
            }
            throw new RuntimeException("Error al guardar en la base de datos: " + e.getMessage());
        }
    }

    public void actualizarEmpleado(int idEmpleado, String nombre, String apellidoPaterno, String apellidoMaterno, String telefono) {
        validarCamposObligatorios(nombre, apellidoPaterno);

        EmpleadoEntity empleadoExistente = empleadoRepositorio.buscarPorId(idEmpleado);
        if (empleadoExistente == null) {
            throw new IllegalArgumentException("El empleado con ID " + idEmpleado + " no existe.");
        }

        empleadoExistente.setNombre(nombre);
        empleadoExistente.setApellido_paterno(apellidoPaterno);
        empleadoExistente.setApellido_materno(apellidoMaterno);
        empleadoExistente.setTelefono(telefono);

        empleadoRepositorio.guardarOActualizar(empleadoExistente);
    }

    public void eliminarEmpleado(int idEmpleado) {
        EmpleadoEntity empleadoExistente = empleadoRepositorio.buscarPorId(idEmpleado);
        if (empleadoExistente == null) {
            throw new IllegalArgumentException("No se encontró el empleado a eliminar.");
        }
        empleadoRepositorio.eliminar(empleadoExistente);
    }

    public List<EmpleadoEntity> obtenerTodosLosEmpleados() {
        return empleadoRepositorio.obtenerTodos();
    }

    public List<EmpleadoEntity> buscarEmpleadosPorFiltro(String textoBuscado) {
        if (textoBuscado == null || textoBuscado.trim().isEmpty()) {
            return obtenerTodosLosEmpleados();
        }
        return empleadoRepositorio.buscarPorFiltro(textoBuscado);
    }

    private void validarCamposObligatorios(String nombre, String apellidoPaterno) {
        if (nombre == null || nombre.trim().isEmpty()) {
            throw new IllegalArgumentException("El nombre es obligatorio.");
        }
        if (apellidoPaterno == null || apellidoPaterno.trim().isEmpty()) {
            throw new IllegalArgumentException("El apellido paterno es obligatorio.");
        }
    }
}
