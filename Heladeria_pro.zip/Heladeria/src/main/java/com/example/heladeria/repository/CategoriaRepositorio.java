/*package com.example.heladeria.repository;

import com.example.heladeria.model.CategoriaEntity;
import com.example.heladeria.utils.HibernateUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;

public class CategoriaRepositorio {
    public CategoriaEntity buscarPorNombre(String nombre) {
        // Usamos tu clase HibernateUtils para obtener el EntityManager
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("SELECT c FROM CategoriaEntity c WHERE c.nombre = :nombre", CategoriaEntity.class)
                    .setParameter("nombre", nombre)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }
}*/

package com.example.heladeria.repository;

import com.example.heladeria.model.CategoriaEntity;
import com.example.heladeria.utils.HibernateUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;
import java.util.List;

public class CategoriaRepositorio {

    public CategoriaEntity buscarPorNombre(String nombre) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("SELECT c FROM CategoriaEntity c WHERE c.nombre = :nombre", CategoriaEntity.class)
                    .setParameter("nombre", nombre)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            em.close();
        }
    }

    // Metodo para cargar el comboBoX al controller
    public List<CategoriaEntity> obtenerTodas() {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("FROM CategoriaEntity", CategoriaEntity.class).getResultList();
        } finally {
            em.close();
        }
    }
}