package com.example.heladeria.model;

import jakarta.persistence.*;
import java.math.BigDecimal;

@Entity
@Table(name = "productos")
public class ProductoEntity {

    private int id_producto;
    private String nombre;
    private CategoriaEntity categoria;
    private BigDecimal precio;
    private int stock;
    private int activo;

    /*public ProductoEntity(String nombre, CategoriaEntity categoria, BigDecimal precio, int stock, int activo) {
        this.nombre = nombre;
        this.categoria = categoria;
        this.precio = precio;
        this.stock = stock;
        this.activo = activo;
    }*/

    public ProductoEntity() {
        // Constructor vacío obligatorio para que Hibernate pueda mostrar datos en la tabla
    }

    public ProductoEntity(int id, String nombre, BigDecimal precio, int stock) {
        this.id_producto = id;
        this.nombre = nombre;
        this.precio = precio;
        this.stock = stock;
        this.activo = 1; // Lo ponemos como activo por defecto
    }

    @Override
    public String toString() { return nombre; }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_producto")
    public int getId() {
        return id_producto;
    }

    private void setId(int id) {
        this.id_producto = id;
    }

    @Column(name = "nombre", nullable = false, length = 150)
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_categoria", referencedColumnName = "id_categoria", nullable = false)
    public CategoriaEntity getCategoria() {
        return categoria;
    }

    public void setCategoria(CategoriaEntity categoria) {
        this.categoria = categoria;
    }

    @Column(name = "precio", nullable = false, precision = 10, scale = 2)
    public BigDecimal getPrecio() {
        return precio;
    }

    public void setPrecio(BigDecimal precio) {
        this.precio = precio;
    }

    @Column(name = "stock", nullable = false)
    public int getStock() {
        return stock;
    }

    public void setStock(int stock) {
        this.stock = stock;
    }

    @Column(name = "activo", nullable = false)
    public int getActivo() {
        return activo;
    }

    public void setActivo(int activo) {
        this.activo = activo;
    }
}