package com.example.heladeria.controller;

import com.example.heladeria.model.*;
import com.example.heladeria.services.*;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class AdminMovimientoController {

    @FXML private ComboBox<ProductoEntity> cmbProducto;
    @FXML private ComboBox<EmpleadoEntity> cmbEmpleado;
    @FXML private ComboBox<String> cmbTipo;
    @FXML private TextField txtCantidad;

    @FXML private TableView<MovimientoInventarioEntity> tblMovimientos;
    @FXML private TableColumn<MovimientoInventarioEntity, Integer> colId;
    @FXML private TableColumn<MovimientoInventarioEntity, String> colProducto;
    @FXML private TableColumn<MovimientoInventarioEntity, String> colTipo;
    @FXML private TableColumn<MovimientoInventarioEntity, Integer> colCantidad;
    @FXML private TableColumn<MovimientoInventarioEntity, String> colFecha;

    private final MovimientoServicio movimientoServicio = new MovimientoServicio();
    private final ProductoServicio productoServicio = new ProductoServicio();
    private final EmpleadoServicio empleadoServicio = new EmpleadoServicio();

    @FXML
    public void initialize() {
        configurarTabla();
        cargarDatosFormulario();
    }

    private void configurarTabla() {
        // Validación para evitar errores si la tabla no carga
        if (tblMovimientos == null) return;

        colId.setCellValueFactory(new PropertyValueFactory<>("id"));
        colProducto.setCellValueFactory(cellData ->
                new javafx.beans.property.SimpleStringProperty(cellData.getValue().getProducto().getNombre()));
        colTipo.setCellValueFactory(new PropertyValueFactory<>("tipoMovimiento"));
        colCantidad.setCellValueFactory(new PropertyValueFactory<>("cantidad"));
        colFecha.setCellValueFactory(new PropertyValueFactory<>("fecha"));

        actualizarTabla();
    }

    private void cargarDatosFormulario() {
        // Llenado seguro de ComboBoxes
        try {
            if (cmbProducto != null) {
                cmbProducto.setItems(FXCollections.observableArrayList(productoServicio.obtenerTodosLosProductos()));
            }
            if (cmbEmpleado != null) {
                cmbEmpleado.setItems(FXCollections.observableArrayList(empleadoServicio.obtenerTodosLosEmpleados()));
            }
            if (cmbTipo != null) {
                cmbTipo.setItems(FXCollections.observableArrayList("ENTRADA", "SALIDA"));
            }
        } catch (Exception e) {
            System.err.println("Error al cargar datos iniciales: " + e.getMessage());
        }
    }

    @FXML
    void handleAgregar(ActionEvent event) {
        try {
            // BLOQUEO ANTICRASH: Verificamos que los objetos no sean nulos antes de usar getValue()
            if (cmbProducto == null || cmbEmpleado == null || cmbTipo == null) {
                mostrarAlerta("Error de Interfaz", "Los componentes FXML no se cargaron. Revisa los fx:id en Scene Builder.", Alert.AlertType.ERROR);
                return;
            }

            if (cmbProducto.getValue() == null || cmbEmpleado.getValue() == null || cmbTipo.getValue() == null || txtCantidad.getText().isEmpty()) {
                mostrarAlerta("Faltan Datos", "Por favor completa todos los campos de la parte superior.", Alert.AlertType.WARNING);
                return;
            }

            movimientoServicio.registrarMovimiento(
                    cmbProducto.getValue().getId(),
                    cmbEmpleado.getValue().getId(),
                    cmbTipo.getValue(),
                    txtCantidad.getText()
            );

            actualizarTabla();
            limpiarCampos();
            mostrarAlerta("Éxito", "Movimiento registrado correctamente.", Alert.AlertType.INFORMATION);

        } catch (Exception e) {
            mostrarAlerta("Error", "No se pudo registrar: " + e.getMessage(), Alert.AlertType.ERROR);
        }
    }

    private void actualizarTabla() {
        if (tblMovimientos != null) {
            try {
                tblMovimientos.setItems(FXCollections.observableArrayList(new com.example.heladeria.repository.MovimientoRepositorio().obtenerTodos()));
            } catch (Exception e) {
                System.err.println("Error al actualizar tabla: " + e.getMessage());
            }
        }
    }

    private void limpiarCampos() {
        if (txtCantidad != null) txtCantidad.clear();
        if (cmbTipo != null) cmbTipo.getSelectionModel().clearSelection();
        if (cmbProducto != null) cmbProducto.getSelectionModel().clearSelection();
    }

    private void mostrarAlerta(String titulo, String msg, Alert.AlertType tipo) {
        Alert alert = new Alert(tipo);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(msg);
        alert.showAndWait();
    }

    // --- Métodos de Navegación ---
    private void cambiarEscena(ActionEvent event, String rutaFXML, String titulo) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) return;
            Parent root = FXMLLoader.load(fxmlUrl);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(titulo);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML void handleProductos(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminProductos.fxml", "Productos"); }
    @FXML void handleMovimiento(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminMovimiento.fxml", "Movimientos"); }
    @FXML void handleNuevoEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminNuevoEmpleado.fxml", "Nuevo Empleado"); }
    @FXML void handleEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminEmpleado.fxml", "Empleados"); }
    @FXML void handleListado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminListado.fxml", "Listados"); }
    @FXML void handleCerrarSesion(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Login.fxml", "Login"); }
}