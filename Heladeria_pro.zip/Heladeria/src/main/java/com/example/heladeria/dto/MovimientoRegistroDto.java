package com.example.heladeria.dto;

import com.example.heladeria.model.TipoMovimiento;

public record MovimientoRegistroDto (
        TipoMovimiento tipoMovimiento,
        int cantidad,
        int idProducto
){}

