package com.example.heladeria.dto;

public record EmpleadoRegistroDto (
        String nombre,
        String apellidoPaterno,
        String apellidoMaterno,
        String telefono
){}

