package com.example.heladeria.dto;

public record ProductoRegistroDto (
        String nombre,
        double precio,
        int stock
){}

