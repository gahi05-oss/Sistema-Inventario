package com.example.heladeria.controller;

import com.example.heladeria.model.EmpleadoEntity;
import com.example.heladeria.services.EmpleadoServicio;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class AdminEmpleadoController {


    @FXML private TableView<EmpleadoEntity> tablaEmpleados;
    @FXML private TextField txtFiltro;

    private final EmpleadoServicio empleadoServicio = new EmpleadoServicio();

    @FXML
    public void initialize() {
        // No cargamos datos por ahora para evitar el error de recursión de Hibernate (DTO pendiente)
        System.out.println("Vista de Empleados cargada exitosamente.");
    }

    @FXML
    void handleEditar(ActionEvent event) {
        // Obtener el empleado seleccionado de la tabla
        EmpleadoEntity seleccionado = tablaEmpleados.getSelectionModel().getSelectedItem();

        if (seleccionado == null) {
            mostrarAlerta("Atención", "Selecciona un empleado de la tabla para editar.");
            return;
        }

        try {
            // Cargar el FXML del formulario
            FXMLLoader loader = new FXMLLoader(getClass().getResource("/com/example/heladeria/Administrador/AdminNuevoEmpleado.fxml"));
            Parent root = loader.load();

            // Obtener el controlador del formulario y pasarle los datos
            AdminNuevoEmpleadoController controller = loader.getController();
            controller.prepararEdicion(seleccionado);

            // Cambiar la escena
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle("Editar Empleado");
            stage.show();
        } catch (IOException e) {
            System.err.println("Error al cargar la vista de edición: " + e.getMessage());
        }
    }

    @FXML
    void handleBuscar(ActionEvent event) {
        mostrarAlerta("Información", "La búsqueda se habilitará al implementar los DTOs para evitar errores de memoria.");
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    // --- Métodos de Navegación ---
    private void cambiarEscena(ActionEvent event, String rutaFXML, String titulo) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) {
                System.err.println("No se encontró el archivo FXML en la ruta: " + rutaFXML);
                return;
            }
            Parent root = FXMLLoader.load(fxmlUrl);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(titulo);
            stage.show();
        } catch (IOException e) {
            System.err.println("Error al cambiar de escena: " + e.getMessage());
            e.printStackTrace();
        }
    }

    @FXML void handleProductos(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminProductos.fxml", "Productos"); }
    @FXML void handleMovimiento(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminMovimiento.fxml", "Movimientos"); }
    @FXML void handleNuevoEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminNuevoEmpleado.fxml", "Nuevo Empleado"); }
    @FXML void handleEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminEmpleado.fxml", "Empleados"); }
    @FXML void handleListado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminListado.fxml", "Listados"); }
    @FXML void handleCerrarSesion(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Login.fxml", "Login"); }

} // Esta llave debe ser la ÚNICA que cierra la clase al final de todo