package com.example.heladeria.tests;

import com.example.heladeria.dto.MovimientoVistaDto;
import com.example.heladeria.repository.MovimientoRepositorio;

import java.util.List;

public class TestMovimientoInventario {

    public static void main(String[] args) {

        // Instancia del repositorio
        MovimientoRepositorio repository =
                new MovimientoRepositorio();

        // Obtener movimientos
        List<MovimientoVistaDto> movimientos =
                repository.obtenerTodosView();

        // Verificar si existen registros
        if (movimientos.isEmpty()) {

            System.out.println("No se encontraron movimientos.");

        } else {

            System.out.println("}MOVIMIENTOS ENCONTRADOS");

            for (MovimientoVistaDto movimiento : movimientos) {

                System.out.println("----------------------------------");

                System.out.println("Fecha: "
                        + movimiento.getFecha());

                System.out.println("ID Producto: "
                        + movimiento.getIdProducto());

                System.out.println("Nombre Producto: "
                        + movimiento.getNombreProducto());

                System.out.println("Tipo Movimiento: "
                        + movimiento.getTipoMovimiento());

                System.out.println("Cantidad: "
                        + movimiento.getCantidad());

                System.out.println("ID Empleado: "
                        + movimiento.getIdEmpleado());
            }
        }
    }
}
