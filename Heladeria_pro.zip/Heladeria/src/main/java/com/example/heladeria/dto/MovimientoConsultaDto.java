package com.example.heladeria.dto;

public record MovimientoConsultaDto (
        int idMovimiento,
        String tipoMovimiento,
        int cantidad,
        String fecha,
        String nombreProducto
){}

