package com.example.heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class EncargadoActualizarController {

    @FXML
    private ComboBox<String> cmbCategoria;
    @FXML
    private ComboBox<String> cmbFecha;
    @FXML
    private ComboBox<String> cmbTipoES;
    @FXML
    private TableColumn<?, ?> colCategoria;
    @FXML
    private TableColumn<?, ?> colId;
    @FXML
    private TableColumn<?, ?> colNombre;
    @FXML
    private TableColumn<?, ?> colPrecio;
    @FXML
    private TableColumn<?, ?> colStock;
    @FXML
    private TableView<?> tablaProductos;
    @FXML
    private TextField txtCantES;
    @FXML
    private TextField txtFiltro;
    @FXML
    private TextField txtIdProducto;
    @FXML
    private TextField txtNombre;
    @FXML
    private TextField txtPrecio;
    @FXML
    private TextField txtStock;

    @FXML
    public void initialize() {
        if (cmbCategoria != null) {
            cmbCategoria.getItems().addAll("Helados", "Paletas", "Bebidas", "Postres");
        }
        if (cmbTipoES != null) {
            cmbTipoES.getItems().addAll("Entrada", "Salida");
        }
    }

    @FXML
    void handleActualizarCantidades(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Encargado/EncargadoActualizar.fxml", "Actualizar Cantidades");
    }

    @FXML
    void handleRegistros(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Encargado/EncargadoRegistros.fxml", "Registros");
    }

    @FXML
    void handleCerrarSesion(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Login.fxml", "Acceso al Sistema");
    }

    @FXML
    void handleEditar(ActionEvent event) {

        System.out.println("Editando producto ID: " + txtIdProducto.getText());
    }

    @FXML
    void handleBuscar(ActionEvent event) {
        System.out.println("Buscando productos con filtro: " + txtFiltro.getText());
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML, String titulo) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) {
                System.err.println("Error: No se encontró el archivo FXML en " + rutaFXML);
                return;
            }

            Parent root = FXMLLoader.load(fxmlUrl);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(titulo);
            stage.show();

        } catch (IOException e) {
            System.err.println("Error al intentar cambiar de escena:");
            e.printStackTrace();
        }
    }
}
