/*package com.example.heladeria.services;

import com.example.heladeria.model.EmpleadoEntity;
import com.example.heladeria.model.MovimientoInventarioEntity;
import com.example.heladeria.model.ProductoEntity;
import com.example.heladeria.model.TipoMovimiento;
import com.example.heladeria.repository.EmpleadoRepositorio;
import com.example.heladeria.repository.MovimientoRepositorio;
import com.example.heladeria.repository.ProductoRepositorio;
import java.time.LocalDateTime;

public class MovimientoServicio {
    private MovimientoRepositorio movimientoRepo = new MovimientoRepositorio();
    private ProductoRepositorio productoRepo = new ProductoRepositorio();
    private EmpleadoRepositorio empleadoRepo = new EmpleadoRepositorio();

    // 1. REGISTRAR (Entrada o Salida)
    public void registrarMovimiento(int idProducto, int idEmpleado, String tipoTexto, String cantidadTexto) {
        ProductoEntity producto = validarProducto(idProducto);
        EmpleadoEntity empleado = validarEmpleado(idEmpleado);
        TipoMovimiento tipo = parsearTipo(tipoTexto);
        int cantidad = parsearCantidad(cantidadTexto);

        // Verificamos y calculamos el nuevo stock
        int nuevoStock = producto.getStock();
        if (tipo == TipoMovimiento.ENTRADA) {
            nuevoStock += cantidad;
        } else if (tipo == TipoMovimiento.SALIDA) {
            if (producto.getStock() < cantidad) {
                throw new IllegalArgumentException("No hay suficiente stock. Tienes: " + producto.getStock());
            }
            nuevoStock -= cantidad;
        }

        // 1. Actualizamos el stock del producto
        producto.setStock(nuevoStock);
        productoRepo.guardarOActualizar(producto);

        // 2. Creamos el movimiento con la fecha actual y lo guardamos
        MovimientoInventarioEntity movimiento = new MovimientoInventarioEntity(
                producto, empleado, tipo, cantidad, LocalDateTime.now());
        movimientoRepo.guardarOActualizar(movimiento);
    }

    // 2. EDITAR (Revertir el pasado y aplicar el presente)
    public void actualizarMovimiento(int idMovimiento, int idProductoNuevo, String tipoTextoNuevo, String cantidadTextoNueva) {
        MovimientoInventarioEntity movimientoExistente = movimientoRepo.buscarPorId(idMovimiento);
        if (movimientoExistente == null) {
            throw new IllegalArgumentException("El movimiento no existe.");
        }

        ProductoEntity producto = movimientoExistente.getProducto();

        // A. REVERTIMOS EL IMPACTO DEL MOVIMIENTO VIEJO EN EL STOCK
        int stockActual = producto.getStock();
        if (movimientoExistente.getTipoMovimiento() == TipoMovimiento.ENTRADA) {
            stockActual -= movimientoExistente.getCantidad(); // Si antes entró, lo quitamos
        } else {
            stockActual += movimientoExistente.getCantidad(); // Si antes salió, lo regresamos
        }

        // B. APLICAMOS EL IMPACTO DEL MOVIMIENTO NUEVO
        TipoMovimiento tipoNuevo = parsearTipo(tipoTextoNuevo);
        int cantidadNueva = parsearCantidad(cantidadTextoNueva);

        if (tipoNuevo == TipoMovimiento.ENTRADA) {
            stockActual += cantidadNueva;
        } else {
            if (stockActual < cantidadNueva) {
                throw new IllegalArgumentException("La edición dejaría el inventario en números negativos.");
            }
            stockActual -= cantidadNueva;
        }

        // C. GUARDAMOS LOS CAMBIOS EN EL PRODUCTO Y LUEGO EN EL MOVIMIENTO
        producto.setStock(stockActual);
        productoRepo.guardarOActualizar(producto);

        // Si decidieron cambiar de producto, asignamos el nuevo producto (raro, pero posible)
        if(producto.getId() != idProductoNuevo) {
            ProductoEntity productoNuevo = validarProducto(idProductoNuevo);
            movimientoExistente.setProducto(productoNuevo);
        }

        movimientoExistente.setTipoMovimiento(tipoNuevo);
        movimientoExistente.setCantidad(cantidadNueva);
        // La fecha no se cambia para respetar la auditoría
        movimientoRepo.guardarOActualizar(movimientoExistente);
    }

    // 3. ELIMINAR (Revertir el stock y borrar registro)
    public void eliminarMovimiento(int idMovimiento) {
        MovimientoInventarioEntity movimiento = movimientoRepo.buscarPorId(idMovimiento);
        if (movimiento == null) {
            throw new IllegalArgumentException("El movimiento no existe.");
        }

        ProductoEntity producto = movimiento.getProducto();

        // Revertimos el stock
        int stockActual = producto.getStock();
        if (movimiento.getTipoMovimiento() == TipoMovimiento.ENTRADA) {
            stockActual -= movimiento.getCantidad();
        } else {
            stockActual += movimiento.getCantidad();
        }

        if (stockActual < 0) {
            throw new IllegalArgumentException("No se puede eliminar porque dejaría el stock en negativo.");
        }

        producto.setStock(stockActual);
        productoRepo.guardarOActualizar(producto);

        // Borramos físicamente el movimiento
        movimientoRepo.eliminar(movimiento);
    }

    // --- MÉTODOS AUXILIARES DE VALIDACIÓN ---
    private ProductoEntity validarProducto(int idProducto) {
        ProductoEntity producto = productoRepo.buscarPorId(idProducto);
        if (producto == null) throw new IllegalArgumentException("El producto no existe.");
        return producto;
    }

    private EmpleadoEntity validarEmpleado(int idEmpleado) {
        EmpleadoEntity empleado = empleadoRepo.buscarPorId(idEmpleado);
        if (empleado == null) throw new IllegalArgumentException("El empleado no existe.");
        return empleado;
    }

    private int parsearCantidad(String cantidadTexto) {
        if (cantidadTexto == null || cantidadTexto.trim().isEmpty()) {
            throw new IllegalArgumentException("La cantidad no puede estar vacía.");
        }
        try {
            int cantidad = Integer.parseInt(cantidadTexto);
            if (cantidad <= 0) throw new IllegalArgumentException("La cantidad debe ser mayor a 0.");
            return cantidad;
        } catch (NumberFormatException e) {
            throw new IllegalArgumentException("La cantidad debe ser un número entero.");
        }
    }

    private TipoMovimiento parsearTipo(String tipoTexto) {
        try {
            return TipoMovimiento.valueOf(tipoTexto.toUpperCase());
        } catch (Exception e) {
            throw new IllegalArgumentException("El tipo de movimiento debe ser ENTRADA o SALIDA.");
        }
    }
}*/

package com.example.heladeria.services;

import com.example.heladeria.model.*;
import com.example.heladeria.repository.*;
import java.time.LocalDateTime;
import java.util.List;

public class MovimientoServicio {
    private MovimientoRepositorio movimientoRepo = new MovimientoRepositorio();
    private ProductoRepositorio productoRepo = new ProductoRepositorio();
    private EmpleadoRepositorio empleadoRepo = new EmpleadoRepositorio();

    public void registrarMovimiento(int idProducto, int idEmpleado, String tipoTexto, String cantidadTexto) {
        // Validar existencia de entidades
        ProductoEntity producto = productoRepo.buscarPorId(idProducto);
        EmpleadoEntity empleado = empleadoRepo.buscarPorId(idEmpleado);

        if (producto == null) throw new IllegalArgumentException("El producto no existe.");
        if (empleado == null) throw new IllegalArgumentException("El empleado no existe.");

        // Parsear datos
        TipoMovimiento tipo = TipoMovimiento.valueOf(tipoTexto.toUpperCase());
        int cantidad = Integer.parseInt(cantidadTexto);
        if (cantidad <= 0) throw new IllegalArgumentException("La cantidad debe ser positiva.");

        // Lógica de Stock
        int stockActual = producto.getStock();
        if (tipo == TipoMovimiento.ENTRADA) {
            producto.setStock(stockActual + cantidad);
        } else {
            if (stockActual < cantidad) {
                throw new IllegalArgumentException("Stock insuficiente. Disponible: " + stockActual);
            }
            producto.setStock(stockActual - cantidad);
        }

        // Persistir cambios (Producto y luego el registro del Movimiento)
        productoRepo.guardarOActualizar(producto);

        MovimientoInventarioEntity movimiento = new MovimientoInventarioEntity(
                producto, empleado, tipo, cantidad, LocalDateTime.now());
        movimientoRepo.guardarOActualizar(movimiento);
    }

    public List<MovimientoInventarioEntity> obtenerHistorial() {
        return movimientoRepo.obtenerTodos();
    }
}
