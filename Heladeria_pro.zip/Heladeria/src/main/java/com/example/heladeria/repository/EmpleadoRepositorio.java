package com.example.heladeria.repository;

import com.example.heladeria.model.EmpleadoEntity;
import com.example.heladeria.utils.HibernateUtils;
import jakarta.persistence.EntityManager;
import java.util.List;

public class EmpleadoRepositorio {

    public void guardarOActualizar(EmpleadoEntity empleado) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            em.getTransaction().begin();
            if (empleado.getId() == 0) {
                em.persist(empleado);
            } else {
                em.merge(empleado);
            }
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw new RuntimeException("Error en la base de datos al guardar el empleado.", e);
        } finally {
            em.close();
        }
    }
    public EmpleadoEntity buscarPorId(int id) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.find(EmpleadoEntity.class, id);
        } finally {
            em.close();
        }
    }
    public List<EmpleadoEntity> obtenerTodos() {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            return em.createQuery("SELECT e FROM EmpleadoEntity e", EmpleadoEntity.class).getResultList();
        } finally {
            em.close();
        }
    }

    // Búsqueda dinámica por nombre o apellidos
    public List<EmpleadoEntity> buscarPorFiltro(String texto) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            String jpql = "SELECT e FROM EmpleadoEntity e WHERE LOWER(e.nombre) LIKE LOWER(:texto) " +
                    "OR LOWER(e.apellido_paterno) LIKE LOWER(:texto) OR LOWER(e.apellido_materno) LIKE LOWER(:texto)";
            return em.createQuery(jpql, EmpleadoEntity.class)
                    .setParameter("texto", "%" + texto + "%")
                    .getResultList();
        } finally {
            em.close();
        }
    }

    // Borrado físico de la base de datos
    public void eliminar(EmpleadoEntity empleado) {
        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();
        try {
            em.getTransaction().begin();
            EmpleadoEntity empleadoParaBorrar = em.contains(empleado) ? empleado : em.merge(empleado);
            em.remove(empleadoParaBorrar);
            em.getTransaction().commit();
        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            throw new RuntimeException("Error al eliminar el empleado.", e);
        } finally {
            em.close();
        }
    }
}
