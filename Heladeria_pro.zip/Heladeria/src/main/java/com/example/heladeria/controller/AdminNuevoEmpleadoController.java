package com.example.heladeria.controller;

import com.example.heladeria.model.EmpleadoEntity;
import com.example.heladeria.services.EmpleadoServicio;
import javafx.collections.FXCollections;
import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class AdminNuevoEmpleadoController {

    @FXML private TextField txtNombre, txtApellidoP, txtApellidoM, txtTelefono, txtUsuario;
    @FXML private PasswordField txtPassword;
    @FXML private ComboBox<String> cmbRol;
    @FXML private Button btnGuardar;

    private final EmpleadoServicio empleadoServicio = new EmpleadoServicio();
    private int idEmpleadoExistente = 0; // 0 = Nuevo, >0 = Edición

    @FXML
    public void initialize() {
        if (cmbRol != null) {
            cmbRol.setItems(FXCollections.observableArrayList("Administrador", "Empleado"));
        }
    }


    public void prepararEdicion(EmpleadoEntity emp) {
        if (emp == null) return;

        this.idEmpleadoExistente = emp.getId();

        txtNombre.setText(emp.getNombre());
        txtApellidoP.setText(emp.getApellido_paterno());
        txtApellidoM.setText(emp.getApellido_materno());
        txtTelefono.setText(emp.getTelefono());

        if (emp.getUsuario() != null) {
            txtUsuario.setText(emp.getUsuario().getNombre_usuario());
            txtPassword.setText(emp.getUsuario().getPassword());
            cmbRol.setValue(emp.getUsuario().getRol().getNombre());

            // BLOQUEO DE SEGURIDAD para evitar Duplicate Entry en BD
            txtUsuario.setEditable(false);
            txtUsuario.setDisable(true);
            txtPassword.setEditable(false);
            txtPassword.setDisable(true);

            txtUsuario.setStyle("-fx-opacity: 0.8; -fx-background-color: #f0f0f0;");
            txtPassword.setStyle("-fx-opacity: 0.8; -fx-background-color: #f0f0f0;");
        }

        if (btnGuardar != null) btnGuardar.setText("Actualizar Empleado");
    }

    @FXML
    void handleAgregar(ActionEvent event) {
        try {
            // Validación básica para evitar NullPointerException al procesar datos
            if (txtNombre.getText().isEmpty() || txtApellidoP.getText().isEmpty()) {
                mostrarAlerta("Campos Requeridos", "El nombre y apellido paterno son obligatorios.");
                return;
            }

            if (idEmpleadoExistente == 0) {
                // REGISTRO NUEVO
                empleadoServicio.registrarEmpleadoConUsuario(
                        txtNombre.getText(),
                        txtApellidoP.getText(),
                        txtApellidoM.getText(),
                        txtTelefono.getText(),
                        txtUsuario.getText(),
                        txtPassword.getText(),
                        cmbRol.getValue()
                );
                mostrarAlertaExito("Éxito", "Empleado registrado correctamente.");
            } else {
                // ACTUALIZACIÓN (Solo datos personales permitidos)
                empleadoServicio.actualizarEmpleado(
                        idEmpleadoExistente,
                        txtNombre.getText(),
                        txtApellidoP.getText(),
                        txtApellidoM.getText(),
                        txtTelefono.getText()
                );
                mostrarAlertaExito("Éxito", "Empleado actualizado correctamente.");
            }
            handleCancelar(null);
        } catch (Exception e) {
            mostrarAlerta("Error", "No se pudo completar la operación: " + e.getMessage());
        }
    }

    @FXML
    void handleCancelar(ActionEvent event) {
        idEmpleadoExistente = 0;
        txtNombre.clear();
        txtApellidoP.clear();
        txtApellidoM.clear();
        txtTelefono.clear();

        // Restaurar estado de campos de usuario
        txtUsuario.clear();
        txtUsuario.setEditable(true);
        txtUsuario.setDisable(false);
        txtUsuario.setStyle("");

        txtPassword.clear();
        txtPassword.setEditable(true);
        txtPassword.setDisable(false);
        txtPassword.setStyle("");

        cmbRol.getSelectionModel().clearSelection();
        if (btnGuardar != null) btnGuardar.setText("Agregar Empleado");
    }

    private void mostrarAlerta(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.WARNING);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    private void mostrarAlertaExito(String titulo, String mensaje) {
        Alert alert = new Alert(Alert.AlertType.INFORMATION);
        alert.setTitle(titulo);
        alert.setHeaderText(null);
        alert.setContentText(mensaje);
        alert.showAndWait();
    }

    // --- Navegación ---
    private void cambiarEscena(ActionEvent event, String rutaFXML, String titulo) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) return;
            Parent root = FXMLLoader.load(fxmlUrl);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(titulo);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }

    @FXML void handleProductos(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminProductos.fxml", "Productos"); }
    @FXML void handleMovimiento(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminMovimiento.fxml", "Movimientos"); }
    @FXML void handleNuevoEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminNuevoEmpleado.fxml", "Nuevo Empleado"); }
    @FXML void handleEmpleado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminEmpleado.fxml", "Empleados"); }
    @FXML void handleListado(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Administrador/AdminListado.fxml", "Listados"); }
    @FXML void handleCerrarSesion(ActionEvent event) { cambiarEscena(event, "/com/example/heladeria/Login.fxml", "Login"); }
}