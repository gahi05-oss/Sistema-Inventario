package com.example.heladeria.controller;

import com.example.heladeria.Main;
import com.example.heladeria.model.UsuarioEntity;
import com.example.heladeria.services.UsuarioService;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;

public class LoginController {

    @FXML
    private Button btnIniciarSesion;

    @FXML
    private Label lblError;

    @FXML
    private ImageView logoImageView;

    @FXML
    private PasswordField txtContrasena;

    @FXML
    private TextField txtUsuario;

    private final UsuarioService usuarioService = new UsuarioService();

    @FXML
    void handleIniciarSesion() throws IOException {
        String usuario = txtUsuario.getText();
        String password = txtContrasena.getText();

        UsuarioEntity user = usuarioService.login(usuario, password);

        if (user != null) {

            int rolId = user.getRol().getId();

            System.out.println("Login exitoso");

            FXMLLoader fxmlLoader;

            if (rolId == 1) {  // Administrador
                System.out.println("Abrir vista administrador");
                fxmlLoader = new FXMLLoader(Main.class.getResource("Administrador/AdminProductos.fxml"));
            } else {  // Empleado
                fxmlLoader = new FXMLLoader(Main.class.getResource("Encargado/EncargadoActualizar.fxml"));
            }

            Scene scene = new Scene(fxmlLoader.load());
            Stage stage = (Stage) txtUsuario.getScene().getWindow();

            stage.setScene(scene);
            stage.setTitle("Heladería");
            stage.show();

        } else {
            Alert alert = new Alert(Alert.AlertType.ERROR);
            alert.setTitle("Error en inicio de sesión");
            alert.setContentText("Usuario o contraseña incorrectos");
            alert.showAndWait();
        }
    }

}
