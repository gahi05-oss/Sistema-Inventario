package com.example.heladeria.dto;

import com.example.heladeria.model.TipoMovimiento;

import java.time.LocalDateTime;

public class MovimientoVistaDto {

    private LocalDateTime fecha;
    private int idProducto;
    private String nombreProducto;
    private TipoMovimiento tipoMovimiento;
    private int cantidad;
    private int idEmpleado;

    public MovimientoVistaDto(LocalDateTime fecha, int idProducto, String nombreProducto,
                                        TipoMovimiento tipoMovimiento, int cantidad, int idEmpleado) {
        this.fecha = fecha;
        this.idProducto = idProducto;
        this.nombreProducto = nombreProducto;
        this.tipoMovimiento = tipoMovimiento;
        this.cantidad = cantidad;
        this.idEmpleado = idEmpleado;
    }

    public LocalDateTime getFecha() {
        return fecha;
    }

    public int getIdProducto() {
        return idProducto;
    }

    public String getNombreProducto() {
        return nombreProducto;
    }

    public TipoMovimiento getTipoMovimiento() {
        return tipoMovimiento;
    }

    public int getCantidad() {
        return cantidad;
    }

    public int getIdEmpleado() {
        return idEmpleado;
    }
}
