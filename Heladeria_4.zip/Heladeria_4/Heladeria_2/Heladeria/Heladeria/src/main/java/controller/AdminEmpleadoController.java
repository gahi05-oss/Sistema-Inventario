package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;

public class AdminEmpleadoController {

    @FXML private TableView<?> tablaEmpleados;
    @FXML private TableColumn<?, ?> colIdEmple;
    @FXML private TableColumn<?, ?> colNombre;
    @FXML private TableColumn<?, ?> colApellidoP;
    @FXML private TableColumn<?, ?> colApellidoM;
    @FXML private TableColumn<?, ?> colTelefono;
    @FXML private TableColumn<?, ?> colContrasena;
    @FXML private TextField txtFiltro;

    @FXML
    void handleProductos(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminProductos.fxml", "Productos");
    }

    @FXML
    void handleMovimiento(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminMovimiento.fxml", "Movimientos");
    }

    @FXML
    void handleNuevoEmpleado(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminNuevoEmpleado.fxml", "Nuevo Empleado");
    }

    @FXML
    void handleEmpleado(ActionEvent event) {
    }

    @FXML
    void handleListado(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminListado.fxml", "Listados");
    }

    @FXML
    void handleCerrarSesion(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Login.fxml", "Login");
    }

    @FXML
    void handleBuscar(ActionEvent event) {
        System.out.println("Buscando: " + txtFiltro.getText());
    }

    @FXML
    void handleEditar(ActionEvent event) {
    }

    @FXML
    void handleEliminar(ActionEvent event) {
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML, String titulo) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) return;
            Parent root = FXMLLoader.load(fxmlUrl);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(titulo);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}