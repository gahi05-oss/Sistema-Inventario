package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.PasswordField;
import javafx.scene.control.TextField;
import javafx.scene.image.ImageView;
import javafx.stage.Stage;

import java.io.IOException;
import java.net.URL;

public class LoginController {

    @FXML
    private ImageView logoImageView;

    @FXML
    private TextField txtUsuario;

    @FXML
    private PasswordField txtContrasena;

    @FXML
    private Button btnIniciarSesion;

    @FXML
    private Label lblError;

    @FXML
    void handleIniciarSesion(ActionEvent event) {
        String usuario = txtUsuario.getText();
        String password = txtContrasena.getText();

        if (usuario.equals("admin") && password.equals("1234")) {
            try {
                URL adminView = getClass().getResource("/com/example/heladeria/Administrador/AdminProductos.fxml");
                if (adminView == null) {
                    lblError.setText("Error: No se encontro AdminProductos.fxml");
                    return;
                }

                FXMLLoader loader = new FXMLLoader(adminView);
                Parent root = loader.load();

                Stage stage = (Stage) btnIniciarSesion.getScene().getWindow();

                Scene scene = new Scene(root);
                stage.setScene(scene);
                stage.setTitle("Panel de Administracion - Heladeria");
                stage.centerOnScreen();
                stage.show();

            } catch (IOException e) {
                e.printStackTrace();
                lblError.setText("Error al cargar la siguiente ventana.");
            }
        } else {
            lblError.setText("Usuario o contraseña incorrectos.");
        }
    }
}