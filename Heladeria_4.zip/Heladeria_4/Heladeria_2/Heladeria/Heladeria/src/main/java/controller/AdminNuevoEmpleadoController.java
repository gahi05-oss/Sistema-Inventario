package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;

public class AdminNuevoEmpleadoController {

    @FXML private TextField txtIdEmpleado;
    @FXML private TextField txtNombre;
    @FXML private TextField txtApellidoP;
    @FXML private TextField txtApellidoM;
    @FXML private TextField txtTelefono;
    @FXML private PasswordField txtContrasena;
    @FXML private Label lblMensaje;

    @FXML
    void handleProductos(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminProductos.fxml", "Productos");
    }

    @FXML
    void handleMovimiento(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminMovimiento.fxml", "Movimientos");
    }

    @FXML
    void handleNuevoEmpleado(ActionEvent event) {
    }

    @FXML
    void handleEmpleado(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminEmpleado.fxml", "Empleados");
    }

    @FXML
    void handleListado(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminListado.fxml", "Listados");
    }

    @FXML
    void handleCerrarSesion(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Login.fxml", "Login");
    }

    @FXML
    void handleAgregar(ActionEvent event) {
        System.out.println("ID: " + txtIdEmpleado.getText() + " Nombre: " + txtNombre.getText());
        lblMensaje.setText("Empleado agregado");
    }

    @FXML
    void handleCancelar(ActionEvent event) {
        txtIdEmpleado.clear();
        txtNombre.clear();
        txtApellidoP.clear();
        txtApellidoM.clear();
        txtTelefono.clear();
        txtContrasena.clear();
        lblMensaje.setText("");
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML, String titulo) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) return;
            Parent root = FXMLLoader.load(fxmlUrl);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(titulo);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}