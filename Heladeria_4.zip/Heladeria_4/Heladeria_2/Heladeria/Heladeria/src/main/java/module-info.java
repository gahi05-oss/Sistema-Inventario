module com.example.heladeria {
    requires javafx.controls;
    requires javafx.fxml;
    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;

    // Permite que JavaFX acceda al paquete principal y al de controladores
    opens com.example.heladeria to javafx.fxml;
    opens controller to javafx.fxml;

    exports com.example.heladeria;
}