package controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.scene.Node;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*;
import javafx.stage.Stage;
import java.io.IOException;
import java.net.URL;

public class AdminProductosController {

    @FXML private TextField txtIdProducto;
    @FXML private TextField txtNombre;
    @FXML private ComboBox<String> cmbCategoria;
    @FXML private TextField txtStock;
    @FXML private TextField txtPrecio;
    @FXML private TextField txtFiltro;

    @FXML private TableView<?> tablaProductos;
    @FXML private TableColumn<?, ?> colIdProd;
    @FXML private TableColumn<?, ?> colNombre;
    @FXML private TableColumn<?, ?> colCategoria;
    @FXML private TableColumn<?, ?> colStock;
    @FXML private TableColumn<?, ?> colPrecio;

    @FXML
    public void initialize() {
        if (cmbCategoria != null) {
            cmbCategoria.getItems().addAll("Helados", "Paletas", "Bebidas", "Postres");
        }
    }

    @FXML
    void handleProductos(ActionEvent event) {
    }

    @FXML
    void handleMovimiento(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminMovimiento.fxml", "Movimientos");
    }

    @FXML
    void handleNuevoEmpleado(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminNuevoEmpleado.fxml", "Nuevo Empleado");
    }

    @FXML
    void handleEmpleado(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminEmpleado.fxml", "Empleados");
    }

    @FXML
    void handleListado(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Administrador/AdminListado.fxml", "Listados");
    }

    @FXML
    void handleCerrarSesion(ActionEvent event) {
        cambiarEscena(event, "/com/example/heladeria/Login.fxml", "Login");
    }

    @FXML
    void handleAgregar(ActionEvent event) {
        System.out.println("ID: " + txtIdProducto.getText() + " Producto: " + txtNombre.getText());
    }

    @FXML
    void handleBuscar(ActionEvent event) {
        System.out.println("Filtrando por: " + txtFiltro.getText());
    }

    @FXML
    void handleEditar(ActionEvent event) {
    }

    @FXML
    void handleEliminar(ActionEvent event) {
    }

    private void cambiarEscena(ActionEvent event, String rutaFXML, String titulo) {
        try {
            URL fxmlUrl = getClass().getResource(rutaFXML);
            if (fxmlUrl == null) return;
            Parent root = FXMLLoader.load(fxmlUrl);
            Stage stage = (Stage) ((Node) event.getSource()).getScene().getWindow();
            stage.setScene(new Scene(root));
            stage.setTitle(titulo);
            stage.show();
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}