package com.example.heladeria.dto;

public record EmpleadoConsultaDto (
        int idEmpleado,
        String nombreCompleto,
        String telefono,
        String nombreUsuario
) {}
