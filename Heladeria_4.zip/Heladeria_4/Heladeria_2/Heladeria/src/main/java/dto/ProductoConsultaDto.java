package com.example.heladeria.dto;

public record ProductoConsultaDto(
        int idProducto,
        String nombre,
        double precio,
        int stock
) {}