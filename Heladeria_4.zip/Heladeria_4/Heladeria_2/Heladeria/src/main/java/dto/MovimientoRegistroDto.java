package com.example.heladeria.dto;

public record MovimientoRegistroDto(
        String tipoMovimiento,
        int cantidad,
        int idProducto
) {}