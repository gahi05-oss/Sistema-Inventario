module com.example.heladeria {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;

    opens com.example.heladeria to javafx.fxml;
    exports com.example.heladeria;
}