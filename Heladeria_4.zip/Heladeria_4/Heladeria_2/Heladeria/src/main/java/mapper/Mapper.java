package com.example.heladeria.mapper;

import com.example.heladeria.dto.EmpleadoConsultaDto;
import com.example.heladeria.dto.EmpleadoRegistroDto;
import com.example.heladeria.dto.UsuarioRegistroDto;
import com.example.heladeria.dto.ProductoConsultaDto;
import com.example.heladeria.dto.ProductoRegistroDto;
import com.example.heladeria.dto.MovimientoConsultaDto;
import com.example.heladeria.dto.MovimientoRegistroDto;
import com.example.heladeria.model.*;


public class Mapper {

    public static EmpleadoEntity toEmpleadoEntity(EmpleadoRegistroDto dto, UsuarioEntity usuario) {
        return new EmpleadoEntity(
                usuario,
                dto.nombre(),
                dto.apellidoPaterno(),
                dto.apellidoMaterno(),
                dto.telefono()
        );
    }

    public static EmpleadoConsultaDto toEmpleadoConsultaDTO(EmpleadoEntity entity) {
        String nombreCompleto = String.format("%s %s %s",
                entity.getNombre(),
                entity.getApellido_paterno(),
                entity.getApellido_materno()
        ).trim();

        String nombreUsuario = entity.getUsuario() != null
                ? entity.getUsuario().getNombre_usuario()
                : "Sin usuario";

        return new EmpleadoConsultaDto(
                entity.getId(),
                nombreCompleto,
                entity.getTelefono(),
                nombreUsuario
        );
    }

    public static UsuarioEntity toUsuarioEntity(UsuarioRegistroDto dto, RolEntity rol) {
        return new UsuarioEntity(
                dto.nombreUsuario(),
                dto.password(),
                rol,
                1
        );
    }

    // PRODUCTO

    public static ProductoEntity toProductoEntity(ProductoRegistroDto dto) {

        ProductoEntity producto = new ProductoEntity();

        producto.setNombre(dto.nombre());
        producto.setPrecio(dto.precio());
        producto.setStock(dto.stock());

        return producto;
    }

    public static ProductoConsultaDto toProductoConsultaDTO(ProductoEntity entity) {

        return new ProductoConsultaDto(
                entity.getIdProducto(),
                entity.getNombre(),
                entity.getPrecio(),
                entity.getStock()
        );
    }

    // MOVIMIENTO

    public static MovimientoEntity toMovimientoEntity(MovimientoRegistroDto dto, ProductoEntity producto) {

        MovimientoEntity movimiento = new MovimientoEntity();

        movimiento.setTipoMovimiento(dto.tipoMovimiento());
        movimiento.setCantidad(dto.cantidad());
        movimiento.setProducto(producto);

        return movimiento;
    }

    public static MovimientoConsultaDto toMovimientoConsultaDTO(MovimientoEntity entity) {

        return new MovimientoConsultaDto(
                entity.getIdMovimiento(),
                entity.getTipoMovimiento(),
                entity.getCantidad(),
                entity.getFecha().toString(),
                entity.getProducto().getNombre()
        );
    }
}