package com.example.heladeria.model;

public enum TipoMovimiento {
    ENTRADA,
    SALIDA
}
