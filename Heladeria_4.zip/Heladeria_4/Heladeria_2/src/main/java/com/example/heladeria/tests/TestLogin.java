package com.example.heladeria.tests;

import com.example.heladeria.model.UsuarioEntity;
import com.example.heladeria.services.UsuarioService;

public class TestLogin {
    public static void main(String[] args) {

        UsuarioService service = new UsuarioService();

        UsuarioEntity user = service.login("admin", "1234");

        if (user != null) {
            System.out.println("OK");
            System.out.println("Rol: " + user.getRol().getNombre());
        } else {
            System.out.println("ERROR");
        }
    }
}