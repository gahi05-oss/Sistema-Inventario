package com.example.heladeria.controller;

import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.ComboBox;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.TextField;

public class AdminProductosController {

    @FXML
    private ComboBox<?> cmbCategoria;

    @FXML
    private TableColumn<?, ?> colCategoria;

    @FXML
    private TableColumn<?, ?> colId;

    @FXML
    private TableColumn<?, ?> colNombre;

    @FXML
    private TableColumn<?, ?> colPrecio;

    @FXML
    private TableColumn<?, ?> colStock;

    @FXML
    private TableView<?> tablaProductos;

    @FXML
    private TextField txtFiltro;

    @FXML
    private TextField txtIdProducto;

    @FXML
    private TextField txtNombre;

    @FXML
    private TextField txtPrecio;

    @FXML
    private TextField txtStock;

    @FXML
    void handleAgregar(ActionEvent event) {

    }

    @FXML
    void handleBuscar(ActionEvent event) {

    }

    @FXML
    void handleCerrarSesion(ActionEvent event) {

    }

    @FXML
    void handleEditar(ActionEvent event) {

    }

    @FXML
    void handleEliminar(ActionEvent event) {

    }

    @FXML
    void handleEmpleado(ActionEvent event) {

    }

    @FXML
    void handleListado(ActionEvent event) {

    }

    @FXML
    void handleMovimiento(ActionEvent event) {

    }

    @FXML
    void handleNuevoEmpleado(ActionEvent event) {

    }

    @FXML
    void handleProductos(ActionEvent event) {

    }

}
