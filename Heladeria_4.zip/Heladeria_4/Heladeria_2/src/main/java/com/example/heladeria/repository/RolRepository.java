package com.example.heladeria.repository;

import com.example.heladeria.model.RolEntity;
import com.example.heladeria.utils.HibernateUtils;
import jakarta.persistence.EntityManager;

public class RolRepository {
    public long countRoles() {

        EntityManager entityManager = HibernateUtils.getEntityManagerFactory().createEntityManager();

        long total = entityManager.createQuery(
                "SELECT COUNT(r) FROM RolEntity r",
                Long.class
        ).getSingleResult();

        entityManager.close();

        return total;
    }

    public void addRol(RolEntity rol) {

        EntityManager em = HibernateUtils.getEntityManagerFactory().createEntityManager();

        em.getTransaction().begin();
        em.persist(rol);
        em.getTransaction().commit();

        em.close();
    }
}
