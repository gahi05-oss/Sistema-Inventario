package com.example.heladeria.mapper;

import com.example.heladeria.dto.*;
import com.example.heladeria.model.*;

import java.math.BigDecimal;

public class Mapper {

    // EMPLEADO

    public static EmpleadoEntity toEmpleadoEntity(EmpleadoRegistroDto dto, UsuarioEntity usuario) {

        return new EmpleadoEntity(
                usuario,
                dto.nombre(),
                dto.apellidoPaterno(),
                dto.apellidoMaterno(),
                dto.telefono()
        );
    }

    public static EmpleadoConsultaDto toEmpleadoConsultaDTO(EmpleadoEntity entity) {

        String nombreCompleto = String.format("%s %s %s",
                entity.getNombre(),
                entity.getApellido_paterno(),
                entity.getApellido_materno()
        ).trim();

        String nombreUsuario = entity.getUsuario() != null
                ? entity.getUsuario().getNombre_usuario()
                : "Sin usuario";

        return new EmpleadoConsultaDto(
                entity.getId(),
                nombreCompleto,
                entity.getTelefono(),
                nombreUsuario
        );
    }

    // USUARIO

    public static UsuarioEntity toUsuarioEntity(UsuarioRegistroDto dto, RolEntity rol) {

        return new UsuarioEntity(
                dto.nombreUsuario(),
                dto.password(),
                rol,
                1
        );
    }

    // PRODUCTO

    public static ProductoEntity toProductoEntity(ProductoRegistroDto dto) {

        ProductoEntity producto = new ProductoEntity();

        producto.setNombre(dto.nombre());
        producto.setPrecio(BigDecimal.valueOf(dto.precio()));
        producto.setStock(dto.stock());

        return producto;
    }

    public static ProductoConsultaDto toProductoConsultaDTO(ProductoEntity entity) {

        return new ProductoConsultaDto(
                entity.getId(),
                entity.getNombre(),
                entity.getPrecio(),
                entity.getStock()
        );
    }

    // MOVIMIENTO

    public static MovimientoInventarioEntity toMovimientoEntity(
            MovimientoRegistroDto dto,
            ProductoEntity producto
    ) {

        MovimientoInventarioEntity movimiento = new MovimientoInventarioEntity();

        movimiento.setTipoMovimiento(dto.tipoMovimiento());
        movimiento.setCantidad(dto.cantidad());
        movimiento.setProducto(producto);

        return movimiento;
    }

    public static MovimientoConsultaDto toMovimientoConsultaDTO(
            MovimientoInventarioEntity entity
    ) {

        return new MovimientoConsultaDto(
                entity.getId(),
                entity.getTipoMovimiento().name(),
                entity.getCantidad(),
                entity.getFecha().toString(),
                entity.getProducto().getNombre()
        );
    }
}