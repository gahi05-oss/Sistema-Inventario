package com.example.heladeria.services;

import com.example.heladeria.model.UsuarioEntity;
import com.example.heladeria.repository.UsuarioRepository;

public class UsuarioService {
    private final UsuarioRepository usuarioRepository = new UsuarioRepository();

    public UsuarioEntity login(String nombreUsuario, String password) {

        if (nombreUsuario == null || nombreUsuario.isBlank()) {
            return null;
        }

        if (password == null || password.isBlank()) {
            return null;
        }

        return usuarioRepository.login(nombreUsuario, password);
    }
}
