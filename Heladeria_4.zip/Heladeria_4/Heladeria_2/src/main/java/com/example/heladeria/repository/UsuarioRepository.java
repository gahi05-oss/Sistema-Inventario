package com.example.heladeria.repository;

import com.example.heladeria.model.UsuarioEntity;
import com.example.heladeria.utils.HibernateUtils;
import jakarta.persistence.EntityManager;
import jakarta.persistence.NoResultException;

import java.util.List;

public class UsuarioRepository {
    public UsuarioEntity login(String nombreUsuario, String password) {
        EntityManager entityManager = HibernateUtils.getEntityManagerFactory().createEntityManager();

        try {
            return entityManager.createNamedQuery("UsuarioEntity.login", UsuarioEntity.class)
                    .setParameter("nombre", nombreUsuario)
                    .setParameter("password", password)
                    .getSingleResult();
        } catch (NoResultException e) {
            return null;
        } finally {
            entityManager.close();
        }
    }

    public void addUser(UsuarioEntity usuario) {
        EntityManager entityManager = HibernateUtils.getEntityManagerFactory().createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.persist(usuario);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public List<UsuarioEntity> getAllUsers() {
        EntityManager entityManager = HibernateUtils.getEntityManagerFactory().createEntityManager();
        List<UsuarioEntity> result = entityManager.createQuery( "from UsuarioEntity", UsuarioEntity.class ).getResultList();
        entityManager.close();
        return result;
    }

    public UsuarioEntity getUserByID(int id) {
        EntityManager entityManager = HibernateUtils.getEntityManagerFactory().createEntityManager();
        UsuarioEntity usuario = entityManager.find(UsuarioEntity.class, id);
        return usuario;
    }

    public void updateUser(UsuarioEntity usuario) {
        EntityManager entityManager = HibernateUtils.getEntityManagerFactory().createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.merge(usuario);
        entityManager.getTransaction().commit();
        entityManager.close();
    }

    public void removeUser(UsuarioEntity usuario) {
        EntityManager entityManager = HibernateUtils.getEntityManagerFactory().createEntityManager();
        entityManager.getTransaction().begin();
        entityManager.remove(entityManager.merge(usuario));
        entityManager.getTransaction().commit();
        entityManager.close();
    }

}
