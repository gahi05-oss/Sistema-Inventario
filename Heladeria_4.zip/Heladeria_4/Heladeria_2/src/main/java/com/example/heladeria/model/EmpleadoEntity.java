package com.example.heladeria.model;

import jakarta.persistence.*;

@Entity
@Table(name = "empleados")
public class EmpleadoEntity {
    private int id_empleado;
    private UsuarioEntity usuario;
    private String nombre;
    private String apellido_paterno;
    private String apellido_materno;
    private String telefono;

    public EmpleadoEntity() {
    }

    public EmpleadoEntity(UsuarioEntity usuario, String nombre, String apellido_paterno,
                          String apellido_materno, String telefono) {
        this.usuario = usuario;
        this.nombre = nombre;
        this.apellido_paterno = apellido_paterno;
        this.apellido_materno = apellido_materno;
        this.telefono = telefono;
    }
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_empleado")
    public int getId() {
        return id_empleado;
    }

    private void setId(int id) {
        this.id_empleado = id;
    }

    @OneToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "id_usuario", referencedColumnName = "id_usuario", unique = true, nullable = true)
    public UsuarioEntity getUsuario() {
        return usuario;
    }

    public void setUsuario(UsuarioEntity usuario) {
        this.usuario = usuario;
    }

    @Column(name = "nombre", nullable = false, length = 100)
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }

    @Column(name = "apellido_paterno", nullable = false, length = 100)
    public String getApellido_paterno() {
        return apellido_paterno;
    }

    public void setApellido_paterno(String apellido_paterno) {
        this.apellido_paterno = apellido_paterno;
    }

    @Column(name = "apellido_materno", length = 100)
    public String getApellido_materno() {
        return apellido_materno;
    }

    public void setApellido_materno(String apellido_materno) {
        this.apellido_materno = apellido_materno;
    }

    @Column(name = "telefono", length = 20)
    public String getTelefono() {
        return telefono;
    }

    public void setTelefono(String telefono) {
        this.telefono = telefono;
    }


}
