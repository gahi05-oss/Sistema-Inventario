package com.example.heladeria.utils;

import com.example.heladeria.model.RolEntity;
import com.example.heladeria.model.UsuarioEntity;
import com.example.heladeria.repository.RolRepository;
import com.example.heladeria.repository.UsuarioRepository;

public class DataInitializer {

    private final RolRepository rolRepository = new RolRepository();
    private final UsuarioRepository usuarioRepository = new UsuarioRepository();

    public void initializeData() {

        // Verificar si ya existen roles
        if (rolRepository.countRoles() == 0) {

            // Crear roles
            RolEntity adminRol = new RolEntity();
            adminRol.setNombre("administrador");

            RolEntity empleadoRol = new RolEntity();
            empleadoRol.setNombre("empleado");

            rolRepository.addRol(adminRol); // rolId == 1
            rolRepository.addRol(empleadoRol); // rolId == 2

            // Crear usuarios
            UsuarioEntity admin = new UsuarioEntity();
            admin.setNombre_usuario("angelAdmin");
            admin.setPassword("1234");
            admin.setActivo(1);
            admin.setRol(adminRol);

            usuarioRepository.addUser(admin);

            UsuarioEntity rodrigo = new UsuarioEntity();
            rodrigo.setNombre_usuario("rodrigo");
            rodrigo.setPassword("1234");
            rodrigo.setActivo(1);
            rodrigo.setRol(empleadoRol);

            usuarioRepository.addUser(rodrigo);

            System.out.println("Datos iniciales creados");
        }
    }
}
