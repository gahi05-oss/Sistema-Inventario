package com.example.heladeria.model;

import jakarta.persistence.*;

@Entity
@Table(name = "categorias")
public class CategoriaEntity {

    private int id_categoria;
    private String nombre;

    public CategoriaEntity() {
    }

    public CategoriaEntity(String nombre) {
        this.nombre = nombre;
    }

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Column(name = "id_categoria")
    public int getId() {
        return id_categoria;
    }

    private void setId(int id) {
        this.id_categoria = id;
    }

    @Column(name = "nombre", nullable = false, unique = true, length = 100)
    public String getNombre() {
        return nombre;
    }

    public void setNombre(String nombre) {
        this.nombre = nombre;
    }
}