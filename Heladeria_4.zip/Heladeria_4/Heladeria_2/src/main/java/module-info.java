module com.example.heladeria {
    requires javafx.controls;
    requires javafx.fxml;

    requires org.controlsfx.controls;
    requires com.dlsc.formsfx;
    requires jakarta.persistence;
    requires org.hibernate.orm.core;

    opens com.example.heladeria to javafx.fxml;
    opens com.example.heladeria.controller to javafx.fxml;

    exports com.example.heladeria;
    exports com.example.heladeria.model;
    opens com.example.heladeria.model to javafx.fxml, org.hibernate.orm.core;
}